# Conclusiones

## Estado Actual del Proyecto

- Actualmente el proyecto se encuentra en un estado funcional y estable, el usuario estudiante puede matricularse, desmatricularse, revisar sus notas, pedir un certificado, etc.

- El profesor puede asignar y revisar notas de los estudiantes matriculados, puede crear nuevas clases, etc.

## Futuras Actualizaciones

- Dar la posibilidad de que el profesor cree actividades en las que el alumno deba entregar la tarea subiendo archivos o escribiendo en esta misma.

- Añadir un chat privado o por clases para que haya comunicación entre el alumnado y el profesorado.

## Lecciones aprendidas

- El desarrollo a avanzado sin pausa pero sin prisa, trabajando todos los días. Hemos sufrido algunos inconvenientes que nos han retrasado, pero al final hemos conseguido sacar el proyecto adelante.

- Algunas mejoras para futuros proyectos serían planificar mejor el objetivo y el diseño de la aplicación antes de trabajar en ella.
