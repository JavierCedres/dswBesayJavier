# Introducción

## Propósito

- El objetivo de esta documentación es facilitar el uso del proyecto para que los usuarios que revisen este puedan entender el codigo y que se quiere conseguir.

## Visión General del Proyecto

- Este software facilita la documentación de proyectos, simplificandola y puediendo organizar la estructura del documento de una manera más sencilla mediante Markdown

## Audiencia objetivo

- Esta documentación la usarán los administradores, desarrolladores y testers del proyecto
